"""
preprocess.py
=============
Full data-cleaning & preprocessing pipeline:
  1. Load raw dataset
  2. Check for NaN / Inf values  → clean
  3. Remove near-zero-variance features
  4. Normalize with StandardScaler
  5. Reduce dimensionality with PCA (keep 95% variance)
  6. Train / Validation / Test split  (70 / 15 / 15)
  7. Save preprocessed artefacts
"""

import pickle
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.feature_selection import VarianceThreshold

SEED = 42


def load_raw(path: str = "dataset/processed/dataset.pkl") -> dict:
    with open(path, "rb") as f:
        return pickle.load(f)


def clean_features(X: np.ndarray) -> np.ndarray:
    """Replace NaN/Inf with column median."""
    print(f"  NaN count  : {np.isnan(X).sum()}")
    print(f"  Inf count  : {np.isinf(X).sum()}")

    # Replace Inf with NaN first, then median-impute
    X = X.copy().astype(np.float64)
    X[np.isinf(X)] = np.nan

    col_medians = np.nanmedian(X, axis=0)
    for col in range(X.shape[1]):
        mask = np.isnan(X[:, col])
        if mask.any():
            X[mask, col] = col_medians[col]

    print(f"  NaN after  : {np.isnan(X).sum()}  ✓")
    return X


def remove_low_variance(X: np.ndarray, threshold: float = 0.001):
    selector = VarianceThreshold(threshold=threshold)
    X_sel = selector.fit_transform(X)
    kept = selector.get_support().sum()
    print(f"  Features before : {X.shape[1]}")
    print(f"  Features after  : {X_sel.shape[1]}  (removed {X.shape[1]-kept} low-variance)")
    return X_sel, selector


def main():
    print("=" * 55)
    print("  Smart Attendance — Data Preprocessing")
    print("=" * 55)

    # ── 1. Load ──────────────────────────────────────────────────
    data = load_raw()
    X_raw = data["X"]
    y_raw = data["y"]
    students = data["students"]

    print(f"\n[STEP 1] Raw dataset")
    print(f"  Shape  : {X_raw.shape}")
    print(f"  Classes: {len(np.unique(y_raw))}")

    # ── 2. Clean ─────────────────────────────────────────────────
    print(f"\n[STEP 2] Cleaning features")
    X_clean = clean_features(X_raw)

    # ── 3. Remove low-variance features ──────────────────────────
    print(f"\n[STEP 3] Variance thresholding")
    X_sel, var_selector = remove_low_variance(X_clean)

    # ── 4. Encode labels ─────────────────────────────────────────
    print(f"\n[STEP 4] Label encoding")
    le = LabelEncoder()
    y_enc = le.fit_transform(y_raw)
    print(f"  Classes : {list(le.classes_)}")

    # ── 5. Train / Val / Test split ───────────────────────────────
    print(f"\n[STEP 5] Train / Val / Test split  (70 / 15 / 15)")
    X_tv, X_test, y_tv, y_test = train_test_split(
        X_sel, y_enc, test_size=0.15, random_state=SEED, stratify=y_enc)
    X_train, X_val, y_train, y_val = train_test_split(
        X_tv, y_tv, test_size=0.15/0.85, random_state=SEED, stratify=y_tv)

    print(f"  Train  : {X_train.shape[0]} samples")
    print(f"  Val    : {X_val.shape[0]} samples")
    print(f"  Test   : {X_test.shape[0]} samples")

    # ── 6. Standardise ───────────────────────────────────────────
    print(f"\n[STEP 6] StandardScaler normalisation")
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val   = scaler.transform(X_val)
    X_test  = scaler.transform(X_test)
    print(f"  Train mean ≈ {X_train.mean():.6f}  std ≈ {X_train.std():.4f}")

    # ── 7. PCA ───────────────────────────────────────────────────
    print(f"\n[STEP 7] PCA (95% variance retained)")
    pca = PCA(n_components=0.95, random_state=SEED)
    X_train = pca.fit_transform(X_train)
    X_val   = pca.transform(X_val)
    X_test  = pca.transform(X_test)
    print(f"  Components kept : {pca.n_components_}")
    print(f"  Variance explained: {pca.explained_variance_ratio_.sum()*100:.2f}%")

    # ── 8. Save ──────────────────────────────────────────────────
    artefacts = {
        "X_train": X_train, "y_train": y_train,
        "X_val":   X_val,   "y_val":   y_val,
        "X_test":  X_test,  "y_test":  y_test,
        "scaler":        scaler,
        "pca":           pca,
        "var_selector":  var_selector,
        "label_encoder": le,
        "students":      students,
    }
    with open("dataset/processed/preprocessed.pkl", "wb") as f:
        pickle.dump(artefacts, f)

    print(f"\n[SUCCESS] Saved → dataset/processed/preprocessed.pkl")
    print(f"  Final feature dims : {X_train.shape[1]}")
    print()


if __name__ == "__main__":
    main()
