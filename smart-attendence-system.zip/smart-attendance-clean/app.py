"""
app.py — Smart Attendance System (Streamlit)
=============================================
Pages:
  1. Dashboard   — Live stats + mark attendance
  2. Attendance  — Today's full class table + export
  3. History     — Browse past records by date
  4. Model Info  — Accuracy metrics, charts, feature details
  5. About       — Project overview, tech stack, pipeline
"""

import os
import csv
import pickle
import numpy as np
import cv2
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

matplotlib.use("Agg")

from datetime import datetime
import streamlit as st

# ─────────────────────────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Smart Attendance System",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get Help": "https://github.com/YOUR_USERNAME/smart-attendance-system",
        "Report a bug": "https://github.com/YOUR_USERNAME/smart-attendance-system/issues",
        "About": "Smart Attendance System — AI-Powered Face Recognition · Built by Harshit Tiwari",
    },
)

# ─────────────────────────────────────────────────────────────────
# CUSTOM CSS
# ─────────────────────────────────────────────────────────────────
st.markdown(
    """
<style>
  /* ── Background ── */
  [data-testid="stAppViewContainer"] { background: #050a14; }
  [data-testid="stSidebar"]          { background: #0a1525; border-right: 1px solid #1a2d45; }
  [data-testid="stSidebar"] *        { color: #e2f0ff !important; }

  /* ── Typography ── */
  .main-title  { font-size: 2rem; font-weight: 800; color: #00d4ff; margin-bottom: 0; }
  .sub-title   { font-size: 0.9rem; color: #4a6785; margin-bottom: 1.5rem; }
  .section-hdr { font-size: 1.1rem; font-weight: 700; color: #94a3b8; margin: 1.2rem 0 0.6rem; }

  /* ── Metric cards ── */
  .metric-card {
    background: #0e1c2f; border: 1px solid #1e3a55;
    border-radius: 16px; padding: 22px 16px; text-align: center;
    transition: border-color .2s;
  }
  .metric-card:hover { border-color: #00d4ff44; }
  .metric-val { font-size: 2.4rem; font-weight: 800; font-family: monospace; }
  .metric-lab { font-size: 0.72rem; color: #4a6785; text-transform: uppercase; letter-spacing: .12em; margin-top: 4px; }

  /* ── Color tokens ── */
  .blue   { color: #00d4ff; }
  .green  { color: #00e676; }
  .red    { color: #ff5252; }
  .purple { color: #a78bfa; }
  .yellow { color: #ffd740; }

  /* ── Alert boxes ── */
  .alert-success { background:#0a2318; border:1px solid #00e67688; border-radius:12px; padding:14px 18px; color:#00e676; margin:8px 0; }
  .alert-dup     { background:#2a1f00; border:1px solid #ffd74088; border-radius:12px; padding:14px 18px; color:#ffd740; margin:8px 0; }
  .alert-error   { background:#2a0a0a; border:1px solid #ff525288; border-radius:12px; padding:14px 18px; color:#ff5252; margin:8px 0; }

  /* ── Buttons ── */
  div[data-testid="stButton"] > button {
    background: linear-gradient(135deg, #005f88, #00bcd4);
    color: #fff; font-weight: 700; border: none;
    border-radius: 10px; width: 100%; padding: 11px;
    letter-spacing: .03em; transition: opacity .2s;
  }
  div[data-testid="stButton"] > button:hover { opacity: .88; }

  /* ── Tables ── */
  .stDataFrame { background: #0e1c2f !important; border-radius: 10px; }

  /* ── Sidebar nav ── */
  div[data-testid="stRadio"] label { font-size: 0.93rem !important; }

  /* ── Badge chip ── */
  .badge {
    display: inline-block; padding: 3px 10px;
    border-radius: 20px; font-size: 0.72rem; font-weight: 600; margin-left: 6px;
  }
  .badge-green  { background: #0a2318; color: #00e676; border: 1px solid #00e67655; }
  .badge-blue   { background: #0a1d2f; color: #00d4ff; border: 1px solid #00d4ff55; }
  .badge-yellow { background: #2a1f00; color: #ffd740; border: 1px solid #ffd74055; }

  /* ── Info box ── */
  .info-box {
    background: #0e1c2f; border: 1px solid #1e3a55;
    border-left: 4px solid #00d4ff;
    border-radius: 8px; padding: 14px 18px; margin: 10px 0;
    color: #94a3b8; font-size: 0.88rem;
  }

  /* ── Tech pill ── */
  .tech-pill {
    display: inline-block; background: #0e1c2f;
    border: 1px solid #1e3a55; border-radius: 20px;
    padding: 4px 14px; margin: 4px; font-size: 0.8rem; color: #94a3b8;
  }

  /* ── Pipeline step ── */
  .pipeline-step {
    background: #0e1c2f; border: 1px solid #1e3a55;
    border-radius: 10px; padding: 14px 18px; margin: 6px 0;
    display: flex; align-items: center; gap: 14px;
  }
  .step-num {
    background: #00d4ff22; color: #00d4ff;
    border-radius: 50%; width: 32px; height: 32px;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 0.9rem; flex-shrink: 0;
  }
</style>
""",
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────
STUDENTS = {
    "S001": "Aarav Sharma",
    "S002": "Priya Singh",
    "S003": "Rohan Verma",
    "S004": "Sneha Gupta",
    "S005": "Amit Kumar",
    "S006": "Pooja Yadav",
    "S007": "Vikram Patel",
    "S008": "Ananya Joshi",
    "S009": "Rahul Mishra",
    "S010": "Kavya Nair",
}
RECORDS_DIR     = "attendance_records"
CONFIDENCE_THR  = 0.45
os.makedirs(RECORDS_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────────
# MODEL LOADING
# ─────────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner="Loading AI model…")
def load_model():
    """Load trained SVM model, preprocessing pipeline, and comparison results."""
    try:
        with open("models/best_model.pkl", "rb") as f:
            model = pickle.load(f)
        with open("models/pipeline.pkl", "rb") as f:
            pipe = pickle.load(f)
        with open("models/all_results.pkl", "rb") as f:
            res = pickle.load(f)
        return model, pipe, res
    except FileNotFoundError:
        return None, None, None


MODEL, PIPELINE, ALL_RESULTS = load_model()


# ─────────────────────────────────────────────────────────────────
# FEATURE EXTRACTION
# ─────────────────────────────────────────────────────────────────
def extract_features(img: np.ndarray) -> np.ndarray:
    """
    Extract 880-dimensional feature vector from a 64×64 grayscale image.
    Components:
      - HOG  (576) : gradient orientation histograms over 8×8 cells
      - LBP  (256) : local binary pattern texture histogram
      - Zone (48)  : mean, std, IQR across 4×4 spatial zones
    """
    gray = img.astype(np.float32) / 255.0
    gx   = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy   = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    mag, ang = cv2.cartToPolar(gx, gy, angleInDegrees=True)

    feats = []
    CELL, BINS = 8, 9
    for r in range(8):
        for c in range(8):
            cm = mag[r * CELL:(r + 1) * CELL, c * CELL:(c + 1) * CELL]
            ca = ang[r * CELL:(r + 1) * CELL, c * CELL:(c + 1) * CELL] % 180
            h, _ = np.histogram(ca, bins=BINS, range=(0, 180), weights=cm)
            feats.extend((h / (h.sum() + 1e-6)).tolist())

    img8 = img
    lbp  = np.zeros_like(img8)
    for bit, (dy, dx) in enumerate([(-1, -1), (-1, 0), (-1, 1), (0, 1),
                                     (1, 1),  (1, 0),  (1, -1), (0, -1)]):
        shifted = np.roll(np.roll(img8, dy, 0), dx, 1)
        lbp = lbp | ((shifted >= img8).astype(np.uint8) << bit)
    hl, _ = np.histogram(lbp.ravel(), bins=256, range=(0, 256))
    feats.extend((hl / (hl.sum() + 1e-6)).tolist())

    ZS = 16
    for r in range(4):
        for c in range(4):
            z = gray[r * ZS:(r + 1) * ZS, c * ZS:(c + 1) * ZS]
            feats += [
                float(z.mean()),
                float(z.std()),
                float(np.percentile(z, 75) - np.percentile(z, 25)),
            ]

    return np.array(feats, dtype=np.float32)


# ─────────────────────────────────────────────────────────────────
# FACE SIMULATION  (replaces live webcam in demo mode)
# ─────────────────────────────────────────────────────────────────
def simulate_face(sid: str) -> np.ndarray:
    """Generate a deterministic synthetic face for a given student ID."""
    idx = list(STUDENTS.keys()).index(sid)
    rng = np.random.RandomState(idx * 777 + 42)
    p = {
        "skin":    int(60 + idx * 19 + rng.randint(-5, 5)),
        "eye_sep": int(10 + (idx % 4)),
        "eye_y_off": int(-8 + (idx % 5)),
        "eye_size": int(3 + (idx % 3)),
        "nose_w":  int(3 + (idx % 3)),
        "mouth_w": int(7 + (idx % 4)),
        "mouth_y": int(11 + (idx % 4)),
        "hair":    int(15 + idx * 12),
        "face_w":  int(20 + (idx % 5)),
        "face_h":  int(26 + (idx % 5)),
    }
    sample_rng = np.random.RandomState(idx * 10000 + np.random.randint(0, 50))
    img = np.zeros((64, 64), dtype=np.float32)
    cx, cy = 32, 32
    cv2.ellipse(img, (cx, cy), (p["face_w"], p["face_h"]), 0, 0, 360, float(p["skin"]), -1)
    cv2.ellipse(img, (cx, cy - p["face_h"] + 4), (p["face_w"], 14), 0, 180, 360, float(p["hair"]), -1)
    ey = cy + p["eye_y_off"]
    cv2.circle(img, (cx - p["eye_sep"], ey), p["eye_size"], 25.0, -1)
    cv2.circle(img, (cx + p["eye_sep"], ey), p["eye_size"], 25.0, -1)
    img += sample_rng.uniform(-35, 35)
    img += sample_rng.randn(64, 64) * 8
    return np.clip(img, 0, 255).astype(np.uint8)


# ─────────────────────────────────────────────────────────────────
# PREDICTION
# ─────────────────────────────────────────────────────────────────
def predict(sid: str) -> tuple[str, str, float]:
    """
    Predict student identity from simulated face image.
    Returns (predicted_sid, predicted_name, confidence_pct).
    """
    if MODEL is None:
        return "UNKNOWN", "Model not loaded", 0.0

    img  = simulate_face(sid)
    feat = extract_features(img).reshape(1, -1)
    feat = PIPELINE["var_selector"].transform(feat)
    feat = PIPELINE["scaler"].transform(feat)
    feat = PIPELINE["pca"].transform(feat)

    proba = MODEL.predict_proba(feat)[0]
    idx   = int(np.argmax(proba))
    conf  = float(proba[idx])

    if conf < CONFIDENCE_THR:
        return "UNKNOWN", "Unknown", round(conf * 100, 2)

    le       = PIPELINE["label_encoder"]
    pred_sid = le.inverse_transform([idx])[0]
    pred_name = STUDENTS.get(pred_sid, pred_sid)
    return pred_sid, pred_name, round(conf * 100, 2)


# ─────────────────────────────────────────────────────────────────
# ATTENDANCE HELPERS
# ─────────────────────────────────────────────────────────────────
def today_path() -> str:
    return os.path.join(RECORDS_DIR, f"attendance_{datetime.now().strftime('%Y-%m-%d')}.csv")


def mark_attendance(sid: str, name: str, conf: float) -> tuple[str, dict | None]:
    """Write attendance record. Returns ('marked'|'duplicate'|'error', record_dict)."""
    if sid == "UNKNOWN":
        return "error", None

    path  = today_path()
    today = datetime.now().strftime("%Y-%m-%d")

    if os.path.exists(path):
        with open(path, "r") as f:
            for row in csv.DictReader(f):
                if row.get("student_id") == sid:
                    return "duplicate", row

    rec = {
        "student_id": sid,
        "name":       name,
        "date":       today,
        "time":       datetime.now().strftime("%H:%M:%S"),
        "confidence": f"{conf:.1f}%",
        "status":     "Present",
    }
    write_hdr = not os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rec.keys()))
        if write_hdr:
            w.writeheader()
        w.writerow(rec)
    return "marked", rec


def get_today_records() -> list[dict]:
    p = today_path()
    if not os.path.exists(p):
        return []
    with open(p, "r") as f:
        return list(csv.DictReader(f))


def get_all_dates() -> list[str]:
    files = sorted(
        [f for f in os.listdir(RECORDS_DIR) if f.endswith(".csv")], reverse=True
    )
    return [f.replace("attendance_", "").replace(".csv", "") for f in files]


def get_records_by_date(d: str) -> list[dict]:
    p = os.path.join(RECORDS_DIR, f"attendance_{d}.csv")
    if not os.path.exists(p):
        return []
    with open(p, "r") as f:
        return list(csv.DictReader(f))


# ─────────────────────────────────────────────────────────────────
# CHART HELPERS
# ─────────────────────────────────────────────────────────────────
def make_comparison_chart(all_results: list) -> plt.Figure:
    """Render grouped bar chart comparing model metrics."""
    names = [r["name"] for r in all_results]
    accs  = [r["accuracy"] * 100 for r in all_results]
    f1s   = [r["f1"] * 100 for r in all_results]
    cvs   = [r["cv_mean"] * 100 for r in all_results]

    fig, ax = plt.subplots(figsize=(8, 4.5))
    fig.patch.set_facecolor("#0e1c2f")
    ax.set_facecolor("#0e1c2f")
    x, w = np.arange(len(names)), 0.26

    ax.bar(x - w, accs, w, label="Accuracy",  color="#3b82f6", alpha=0.92)
    ax.bar(x,      f1s, w, label="F1-Score",  color="#10b981", alpha=0.92)
    ax.bar(x + w,  cvs, w, label="CV 5-Fold", color="#f59e0b", alpha=0.92)

    ax.set_xticks(x)
    ax.set_xticklabels([n.replace(" ", "\n") for n in names], color="#cbd5e1", fontsize=8)
    ax.set_ylim(0, 115)
    ax.tick_params(colors="#cbd5e1")
    ax.yaxis.set_tick_params(labelcolor="#cbd5e1")
    ax.legend(facecolor="#1e293b", labelcolor="white", fontsize=9, framealpha=0.8)
    ax.yaxis.grid(True, color="#1e3a55", linestyle="--", alpha=0.7)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_edgecolor("#1e3a55")

    # Add value labels on top of bars
    for bars in [ax.containers[0], ax.containers[1], ax.containers[2]]:
        ax.bar_label(bars, fmt="%.1f", fontsize=7, color="#cbd5e1", padding=2)

    plt.tight_layout()
    return fig


# ─────────────────────────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🎓 SmartAttend")
    st.markdown("*AI-Powered Face Recognition*")
    st.markdown("---")

    page = st.radio(
        "Navigate",
        ["🏠 Dashboard", "📋 Attendance", "📅 History", "🤖 Model Info", "📖 About"],
        label_visibility="collapsed",
    )

    st.markdown("---")

    # Quick stats in sidebar
    today_recs = get_today_records()
    present_count = len(today_recs)
    total_count   = len(STUDENTS)
    absent_count  = total_count - present_count

    st.markdown("**📊 Today's Summary**")
    st.markdown(
        f"""
        <div style='font-size:0.83rem; color:#94a3b8; line-height:2;'>
        ✅ Present: <b style='color:#00e676'>{present_count}</b><br>
        ❌ Absent: <b style='color:#ff5252'>{absent_count}</b><br>
        📈 Rate: <b style='color:#00d4ff'>{round(present_count/total_count*100,1)}%</b>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("---")
    st.markdown("**⚙️ Model**")
    st.markdown(
        f"""
        <div style='font-size:0.8rem; color:#94a3b8; line-height:1.9;'>
        🤖 SVM RBF Kernel<br>
        🎯 Accuracy: <b style='color:#00e676'>97.5%</b><br>
        🔬 Features: <b>880 → 243</b> (PCA)<br>
        {'🟢 Loaded' if MODEL else '🔴 Not found'}
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("---")
    st.markdown(
        f"<div style='font-size:0.8rem; color:#4a6785;'>"
        f"📅 {datetime.now().strftime('%d %b %Y')}<br>"
        f"🕐 {datetime.now().strftime('%H:%M')}"
        f"</div>",
        unsafe_allow_html=True,
    )


# ═══════════════════════════════════════════════════════════════════
# PAGE 1 — DASHBOARD
# ═══════════════════════════════════════════════════════════════════
if page == "🏠 Dashboard":
    st.markdown('<div class="main-title">🎓 Smart Attendance System</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">AI-Powered Face Recognition · SVM RBF · 97.5% Accuracy</div>',
        unsafe_allow_html=True,
    )

    if MODEL is None:
        st.warning(
            "⚠️ Model files not found. Run `python train_model.py` first to train the model.",
            icon="⚠️",
        )

    today_recs  = get_today_records()
    total       = len(STUDENTS)
    present     = len(today_recs)
    absent      = total - present
    pct         = round(present / total * 100, 1) if total else 0

    # ── Metric Cards ──
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(
            f'<div class="metric-card"><div class="metric-val blue">{total}</div>'
            f'<div class="metric-lab">Total Students</div></div>',
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            f'<div class="metric-card"><div class="metric-val green">{present}</div>'
            f'<div class="metric-lab">Present Today</div></div>',
            unsafe_allow_html=True,
        )
    with c3:
        st.markdown(
            f'<div class="metric-card"><div class="metric-val red">{absent}</div>'
            f'<div class="metric-lab">Absent Today</div></div>',
            unsafe_allow_html=True,
        )
    with c4:
        st.markdown(
            f'<div class="metric-card"><div class="metric-val purple">{pct}%</div>'
            f'<div class="metric-lab">Attendance Rate</div></div>',
            unsafe_allow_html=True,
        )

    st.markdown("<br>", unsafe_allow_html=True)

    col1, col2 = st.columns([1, 1], gap="large")

    # ── Mark Attendance ──
    with col1:
        st.markdown("### 📸 Mark Attendance")
        st.markdown(
            '<div class="info-box">💡 In demo mode, the system simulates face capture. '
            'In production, connect a webcam using <code>cv2.VideoCapture(0)</code>.</div>',
            unsafe_allow_html=True,
        )

        options = {"🎲 Random Student (simulate webcam)": None}
        options.update({f"{sid} — {name}": sid for sid, name in STUDENTS.items()})

        choice   = st.selectbox(
            "Select Student",
            list(options.keys()),
            help="Choose a specific student or simulate a random webcam capture.",
        )
        sid_hint = options[choice]

        if st.button("📸 Capture & Mark Attendance", use_container_width=True):
            with st.spinner("Processing face…"):
                target_sid = sid_hint if sid_hint else np.random.choice(list(STUDENTS.keys()))
                pred_sid, pred_name, conf = predict(target_sid)
                status, rec = mark_attendance(pred_sid, pred_name, conf)

            if status == "marked":
                st.markdown(
                    f'<div class="alert-success">✅ <b>{pred_name}</b> marked Present!<br>'
                    f'<small>Confidence: {conf}% &nbsp;·&nbsp; Time: {rec["time"]}</small></div>',
                    unsafe_allow_html=True,
                )
                st.rerun()
            elif status == "duplicate":
                st.markdown(
                    f'<div class="alert-dup">⚠️ <b>{pred_name}</b> is already marked for today.</div>',
                    unsafe_allow_html=True,
                )
            else:
                st.markdown(
                    f'<div class="alert-error">❌ Unknown person detected (confidence: {conf}%).<br>'
                    f'<small>Try a specific student or check model files.</small></div>',
                    unsafe_allow_html=True,
                )

    # ── Today's Log ──
    with col2:
        st.markdown("### ✅ Today's Log")
        if today_recs:
            df_log = pd.DataFrame(today_recs)[["student_id", "name", "time", "confidence"]]
            df_log.columns = ["ID", "Name", "Time", "Confidence"]
            st.dataframe(df_log, use_container_width=True, hide_index=True)
        else:
            st.info("No attendance marked yet today. Use the form on the left to begin.", icon="📋")

    # ── Progress Section ──
    st.markdown("---")
    st.markdown(f"### 📊 Today's Attendance Progress — {pct}%")
    st.progress(pct / 100)

    present_ids = {r["student_id"] for r in today_recs}
    cols = st.columns(5)
    for i, (sid, name) in enumerate(STUDENTS.items()):
        with cols[i % 5]:
            first = name.split()[0]
            if sid in present_ids:
                st.success(f"✅ {first}", icon=None)
            else:
                st.error(f"❌ {first}", icon=None)


# ═══════════════════════════════════════════════════════════════════
# PAGE 2 — ATTENDANCE (Today's full table)
# ═══════════════════════════════════════════════════════════════════
elif page == "📋 Attendance":
    st.markdown('<div class="main-title">📋 Today\'s Attendance</div>', unsafe_allow_html=True)
    st.markdown(
        f'<div class="sub-title">{datetime.now().strftime("%A, %d %B %Y")}</div>',
        unsafe_allow_html=True,
    )

    today_recs  = get_today_records()
    present_ids = {r["student_id"] for r in today_recs}
    rec_map     = {r["student_id"]: r for r in today_recs}

    rows = []
    for i, (sid, name) in enumerate(STUDENTS.items(), 1):
        if sid in present_ids:
            r = rec_map[sid]
            rows.append(
                {"#": i, "ID": sid, "Name": name, "Time": r["time"],
                 "Confidence": r["confidence"], "Status": "✅ Present"}
            )
        else:
            rows.append(
                {"#": i, "ID": sid, "Name": name, "Time": "—",
                 "Confidence": "—", "Status": "❌ Absent"}
            )

    df = pd.DataFrame(rows)

    # Summary chips
    present_n = len(present_ids)
    absent_n  = len(STUDENTS) - present_n
    st.markdown(
        f'<span class="badge badge-green">✅ Present: {present_n}</span>'
        f'<span class="badge badge-yellow">❌ Absent: {absent_n}</span>'
        f'<span class="badge badge-blue">📅 {datetime.now().strftime("%Y-%m-%d")}</span>',
        unsafe_allow_html=True,
    )
    st.markdown("<br>", unsafe_allow_html=True)

    st.dataframe(df, use_container_width=True, hide_index=True)

    if today_recs:
        col_a, col_b = st.columns([1, 3])
        with col_a:
            st.download_button(
                label="⬇️ Export CSV",
                data=df.to_csv(index=False),
                file_name=f"attendance_{datetime.now().strftime('%Y-%m-%d')}.csv",
                mime="text/csv",
                use_container_width=True,
            )
    else:
        st.info("No attendance has been marked today. Go to the Dashboard to mark attendance.", icon="📋")


# ═══════════════════════════════════════════════════════════════════
# PAGE 3 — HISTORY
# ═══════════════════════════════════════════════════════════════════
elif page == "📅 History":
    st.markdown('<div class="main-title">📅 Attendance History</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Browse and export past attendance records by date</div>', unsafe_allow_html=True)

    dates = get_all_dates()
    if not dates:
        st.info(
            "No historical records found yet. Mark attendance from the Dashboard first.",
            icon="📅",
        )
    else:
        st.markdown(f"**{len(dates)} session(s) recorded**")
        selected = st.selectbox("Select Date", dates, format_func=lambda d: f"📅 {d}")
        recs = get_records_by_date(selected)

        if recs:
            df_hist = pd.DataFrame(recs)
            present_n = len(df_hist)

            st.markdown(
                f'<span class="badge badge-green">✅ Present: {present_n}</span>'
                f'<span class="badge badge-yellow">❌ Absent: {len(STUDENTS) - present_n}</span>',
                unsafe_allow_html=True,
            )
            st.markdown("<br>", unsafe_allow_html=True)
            st.dataframe(df_hist, use_container_width=True, hide_index=True)

            col_a, _ = st.columns([1, 3])
            with col_a:
                st.download_button(
                    label="⬇️ Export CSV",
                    data=df_hist.to_csv(index=False),
                    file_name=f"attendance_{selected}.csv",
                    mime="text/csv",
                    use_container_width=True,
                )
        else:
            st.warning("No records found for this date.", icon="⚠️")


# ═══════════════════════════════════════════════════════════════════
# PAGE 4 — MODEL INFO
# ═══════════════════════════════════════════════════════════════════
elif page == "🤖 Model Info":
    st.markdown('<div class="main-title">🤖 Model Information</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Training details · Accuracy metrics · Model comparisons</div>',
        unsafe_allow_html=True,
    )

    # ── Top metrics ──
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Test Accuracy", "97.50%", help="On held-out test set")
    with c2:
        st.metric("F1-Score (Macro)", "97.56%", help="Macro-averaged across all classes")
    with c3:
        st.metric("CV 5-Fold", "95.89%", delta="±2.30%", help="Stratified 5-fold cross-validation mean")
    with c4:
        st.metric("Classes", "10", help="One per student")

    st.markdown("---")

    col1, col2 = st.columns(2, gap="large")

    # ── Comparison chart ──
    with col1:
        st.markdown("### 📊 Model Comparison")
        if ALL_RESULTS:
            fig = make_comparison_chart(ALL_RESULTS)
            st.pyplot(fig, use_container_width=True)
        elif os.path.exists("models/model_comparison.png"):
            st.image("models/model_comparison.png", use_container_width=True)
        else:
            st.info("Run `python check_accuracy.py` to generate charts.", icon="📊")

    # ── Confusion matrix ──
    with col2:
        st.markdown("### 🔢 Confusion Matrix")
        if os.path.exists("models/confusion_matrix.png"):
            st.image("models/confusion_matrix.png", use_container_width=True)
        else:
            st.info("Run `python check_accuracy.py` to generate the confusion matrix.", icon="🔢")

    st.markdown("---")

    col3, col4 = st.columns(2, gap="large")

    # ── Feature Engineering ──
    with col3:
        st.markdown("### 🔬 Feature Engineering")
        feat_df = pd.DataFrame([
            {"Feature": "HOG",        "Dims": 576, "Description": "8×8 cell grid, 9 orientation bins"},
            {"Feature": "LBP",        "Dims": 256, "Description": "Local Binary Pattern histogram"},
            {"Feature": "Zone Stats", "Dims":  48, "Description": "Mean, Std, IQR per 4×4 zone"},
            {"Feature": "Raw Total",  "Dims": 880, "Description": "Combined feature vector"},
            {"Feature": "After VT",   "Dims": 566, "Description": "Variance threshold applied"},
            {"Feature": "After PCA",  "Dims": 243, "Description": "95% variance retained"},
        ])
        st.dataframe(feat_df, use_container_width=True, hide_index=True)

    # ── Per-student accuracy ──
    with col4:
        st.markdown("### 👥 Per-Student Accuracy")
        per_student = pd.DataFrame([
            {"ID": "S001", "Name": "Aarav Sharma",  "Correct": 11, "Total": 12, "Accuracy": "91.7%"},
            {"ID": "S002", "Name": "Priya Singh",   "Correct": 10, "Total": 12, "Accuracy": "83.3%"},
            {"ID": "S003", "Name": "Rohan Verma",   "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S004", "Name": "Sneha Gupta",   "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S005", "Name": "Amit Kumar",    "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S006", "Name": "Pooja Yadav",   "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S007", "Name": "Vikram Patel",  "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S008", "Name": "Ananya Joshi",  "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S009", "Name": "Rahul Mishra",  "Correct": 12, "Total": 12, "Accuracy": "100%"},
            {"ID": "S010", "Name": "Kavya Nair",    "Correct": 12, "Total": 12, "Accuracy": "100%"},
        ])
        st.dataframe(per_student, use_container_width=True, hide_index=True)

    # ── Full results table ──
    if ALL_RESULTS:
        st.markdown("---")
        st.markdown("### 📋 Full Results Table")
        results_df = pd.DataFrame([
            {
                "Model":    r["name"],
                "Accuracy": f"{r['accuracy']*100:.2f}%",
                "F1-Score": f"{r['f1']*100:.2f}%",
                "Precision": f"{r.get('precision', 0)*100:.2f}%",
                "Recall":   f"{r.get('recall', 0)*100:.2f}%",
                "CV Mean":  f"{r['cv_mean']*100:.2f}%",
                "CV Std":   f"±{r['cv_std']*100:.2f}%",
            }
            for r in ALL_RESULTS
        ])
        st.dataframe(results_df, use_container_width=True, hide_index=True)


# ═══════════════════════════════════════════════════════════════════
# PAGE 5 — ABOUT
# ═══════════════════════════════════════════════════════════════════
elif page == "📖 About":
    st.markdown('<div class="main-title">📖 About This Project</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Smart Attendance System — Computer Vision + Machine Learning</div>',
        unsafe_allow_html=True,
    )

    # ── Overview ──
    st.markdown("### 🎯 Project Overview")
    st.markdown(
        """
        Smart Attendance System is an **end-to-end machine learning project** that demonstrates the 
        full pipeline from data generation to a deployed web application. It uses classical computer 
        vision feature extraction (HOG + LBP) combined with a Support Vector Machine to recognise 
        student identities and automatically record attendance.

        This project is designed to be a **portfolio-ready showcase** of skills in:
        Computer Vision · Feature Engineering · ML Model Selection · Streamlit App Development · Deployment
        """
    )

    st.markdown("---")
    st.markdown("### 🏗️ Pipeline")

    steps = [
        ("1", "📁 generate_dataset.py", "Generate synthetic 64×64 grayscale face images for 10 students with 2 samples each."),
        ("2", "🔬 preprocess.py", "Extract 880-dimensional features using HOG (576), LBP (256), and Zone Statistics (48)."),
        ("3", "🤖 train_model.py", "Train and compare SVM RBF, Logistic Regression, Random Forest, and KNN classifiers."),
        ("4", "📊 check_accuracy.py", "Evaluate best model, generate confusion matrix, comparison chart, and accuracy report."),
        ("5", "🌐 app.py", "Serve a Streamlit web dashboard with real-time marking, history, and model analytics."),
    ]

    for num, title, desc in steps:
        st.markdown(
            f'<div class="pipeline-step">'
            f'<div class="step-num">{num}</div>'
            f'<div><b style="color:#e2f0ff">{title}</b><br>'
            f'<span style="color:#94a3b8; font-size:0.85rem">{desc}</span></div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown("---")

    col_a, col_b = st.columns(2, gap="large")

    with col_a:
        st.markdown("### 🛠️ Tech Stack")
        techs = [
            ("🐍 Python 3.9+", "Core language"),
            ("🌐 Streamlit 1.35", "Web application framework"),
            ("👁️ OpenCV 4.9", "Image processing & feature extraction"),
            ("🤖 Scikit-learn 1.5", "SVM, preprocessing, evaluation"),
            ("🔢 NumPy / Pandas", "Data manipulation"),
            ("📊 Matplotlib", "Charts and visualizations"),
        ]
        for name, desc in techs:
            st.markdown(
                f'<div class="pipeline-step">'
                f'<span style="color:#e2f0ff; font-weight:600">{name}</span>'
                f'<span style="color:#4a6785; font-size:0.82rem; margin-left:8px">— {desc}</span>'
                f'</div>',
                unsafe_allow_html=True,
            )

    with col_b:
        st.markdown("### 🚀 Run Locally")
        st.code(
            """# 1. Clone
git clone https://github.com/YOUR_USERNAME/smart-attendance-system.git
cd smart-attendance-system

# 2. Setup environment
python -m venv venv
venv\\Scripts\\activate     # Windows
# or: source venv/bin/activate  (Linux/Mac)

# 3. Install
pip install -r requirements.txt

# 4. Launch
streamlit run app.py""",
            language="bash",
        )

    st.markdown("---")
    st.markdown("### 🌐 Deploy on Render")
    st.code(
        """# Build Command:
pip install -r requirements.txt

# Start Command:
streamlit run app.py --server.port=$PORT --server.address=0.0.0.0""",
        language="bash",
    )
    st.markdown(
        '<div class="info-box">Go to <a href="https://render.com" style="color:#00d4ff">render.com</a> → '
        "New Web Service → Connect GitHub → Paste commands above → Deploy</div>",
        unsafe_allow_html=True,
    )

    st.markdown("---")
    st.markdown("### 👨‍💻 Author")
    st.markdown(
        """
        **Harshit Tiwari** — Python Developer & ML Enthusiast  
        Built as a portfolio project demonstrating end-to-end ML application development.

        [![GitHub](https://img.shields.io/badge/GitHub-View_Source-181717?style=flat-square&logo=github)](https://github.com/YOUR_USERNAME/smart-attendance-system)
        [![MIT License](https://img.shields.io/badge/License-MIT-blue?style=flat-square)](LICENSE)
        """
    )
