# Changelog

All notable changes to this project are documented here.

---

## [2.0.0] — 2025

### Added
- 5th page: "About" — project overview, pipeline steps, tech stack, deploy instructions
- Sidebar live stats: present/absent/rate updated every session
- Sidebar model status indicator (loaded / not found)
- Info box on Dashboard explaining demo vs production webcam mode
- `make_comparison_chart()` helper with value labels on bars
- `CONTRIBUTING.md` — contribution guide and open areas
- `LICENSE` — MIT licence file
- `setup.sh` — Streamlit config for Render deployment
- `CHANGELOG.md` — this file

### Improved
- README completely rewritten: badges, feature table, pipeline diagram, performance tables,
  feature engineering table, project structure tree, full deploy guide
- `app.py` fully refactored with docstrings on every function
- CSS: hover effects on metric cards, alert boxes, badge chips, pipeline step cards, info boxes
- Model comparison bar chart now shows value labels above each bar
- Attendance page shows badge chips (Present / Absent / Date)
- History page formats date in selectbox with calendar emoji
- Sidebar shows live summary (present / absent / rate) and model metadata
- `Procfile` updated with `--server.headless=true` flag
- `.gitignore` expanded with Jupyter, swap files, ENV

### Fixed
- `mark_attendance` return type annotated clearly
- Model loading spinner message shown while cache warms up

---

## [1.0.0] — Initial Release

- Streamlit app with 4 pages: Dashboard, Attendance, History, Model Info
- SVM RBF classifier with 97.5% accuracy
- HOG + LBP + Zone Stats feature extraction (880 dims → 243 after PCA)
- CSV-based attendance records
- Basic README with project structure
