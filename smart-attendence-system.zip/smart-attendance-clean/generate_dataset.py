"""
generate_dataset.py  —  IMPROVED VERSION
=========================================
Better synthetic face generation with:
  - More realistic per-student biometric uniqueness
  - Higher intra-class variation (pose, light, noise)
  - Rich feature extraction:
      HOG (8x8 cells, 9 bins)  → 576 dims
    + LBP histogram (uniform)  → 256 dims
    + Pixel intensity stats    →  48 dims
    = 880-dim descriptor       (trimmed by variance threshold later)
"""

import os, pickle
import numpy as np
import cv2

STUDENTS = {
    "S001": "Aarav Sharma",
    "S002": "Priya Singh",
    "S003": "Rohan Verma",
    "S004": "Sneha Gupta",
    "S005": "Amit Kumar",
    "S006": "Pooja Yadav",
    "S007": "Vikram Patel",
    "S008": "Ananya Joshi",
    "S009": "Rahul Mishra",
    "S010": "Kavya Nair",
}
SAMPLES_PER_STUDENT = 80
IMG_SIZE = (64, 64)
SEED = 42
np.random.seed(SEED)

os.makedirs("dataset/raw", exist_ok=True)
os.makedirs("dataset/processed", exist_ok=True)


# ── Per-student unique biometric parameters ───────────────────────
def student_params(idx):
    """Each student gets a unique set of facial geometry params."""
    rng = np.random.RandomState(idx * 777 + 42)
    return {
        "skin":      int(60 + idx * 19 + rng.randint(-5, 5)),
        "eye_sep":   int(10 + (idx % 4)),
        "eye_y_off": int(-8 + (idx % 5)),
        "eye_size":  int(3 + (idx % 3)),
        "nose_w":    int(3 + (idx % 3)),
        "mouth_w":   int(7 + (idx % 4)),
        "mouth_y":   int(11 + (idx % 4)),
        "hair":      int(15 + idx * 12),
        "face_w":    int(20 + (idx % 5)),
        "face_h":    int(26 + (idx % 5)),
    }


def make_face(p, sample_seed):
    """Render a 64x64 grayscale synthetic face with augmentation."""
    rng = np.random.RandomState(sample_seed)
    img = np.zeros(IMG_SIZE, dtype=np.float32)
    cx, cy = 32, 32

    # Face oval
    cv2.ellipse(img, (cx, cy), (p["face_w"], p["face_h"]),
                0, 0, 360, float(p["skin"]), -1)

    # Hair
    cv2.ellipse(img, (cx, cy - p["face_h"] + 4),
                (p["face_w"], 14), 0, 180, 360, float(p["hair"]), -1)

    # Eyes
    ey = cy + p["eye_y_off"]
    cv2.circle(img, (cx - p["eye_sep"], ey), p["eye_size"], 25.0, -1)
    cv2.circle(img, (cx + p["eye_sep"], ey), p["eye_size"], 25.0, -1)
    # Pupils
    cv2.circle(img, (cx - p["eye_sep"], ey), max(1, p["eye_size"]-1), 5.0, -1)
    cv2.circle(img, (cx + p["eye_sep"], ey), max(1, p["eye_size"]-1), 5.0, -1)

    # Eyebrows
    brow_y = ey - p["eye_size"] - 3
    cv2.line(img, (cx - p["eye_sep"] - 4, brow_y),
             (cx - p["eye_sep"] + 4, brow_y - 1), float(p["hair"]), 2)
    cv2.line(img, (cx + p["eye_sep"] - 4, brow_y - 1),
             (cx + p["eye_sep"] + 4, brow_y), float(p["hair"]), 2)

    # Nose
    cv2.ellipse(img, (cx, cy + 2),
                (p["nose_w"], p["nose_w"] + 2), 0, 0, 360,
                float(p["skin"] - 18), -1)
    cv2.line(img, (cx - p["nose_w"], cy + 4),
             (cx + p["nose_w"], cy + 4), float(p["skin"] - 25), 1)

    # Mouth
    cv2.ellipse(img, (cx, cy + p["mouth_y"]),
                (p["mouth_w"], 3), 0, 0, 180, 50.0, 2)

    # ── Augmentation ────────────────────────────────────────────
    # 1. Brightness
    img += rng.uniform(-35, 35)

    # 2. Gaussian noise
    img += rng.randn(*img.shape) * rng.uniform(3, 12)

    # 3. Rotation ±10°
    angle = rng.uniform(-10, 10)
    M = cv2.getRotationMatrix2D((32, 32), angle, 1.0)
    img = cv2.warpAffine(img, M, IMG_SIZE)

    # 4. Horizontal flip (50%)
    if rng.rand() > 0.5:
        img = img[:, ::-1]

    # 5. Slight translation ±3px
    tx, ty = rng.randint(-3, 3), rng.randint(-3, 3)
    Tm = np.float32([[1, 0, tx], [0, 1, ty]])
    img = cv2.warpAffine(img, Tm, IMG_SIZE)

    # 6. Blur (mild, random)
    if rng.rand() > 0.6:
        k = rng.choice([3, 5])
        img = cv2.GaussianBlur(img, (k, k), 0)

    return np.clip(img, 0, 255).astype(np.uint8)


# ── Rich feature extractor ────────────────────────────────────────
def extract_features(img):
    """Return 880-dim descriptor: HOG + LBP + stats."""
    gray = img.astype(np.float32) / 255.0

    feats = []

    # 1. HOG: 8x8 cells over 64x64 → 8x8=64 cells × 9 bins = 576
    gx  = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy  = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    mag, ang = cv2.cartToPolar(gx, gy, angleInDegrees=True)

    CELL = 8  # pixel per cell
    BINS = 9
    N_CELLS = IMG_SIZE[0] // CELL  # 8
    for r in range(N_CELLS):
        for c in range(N_CELLS):
            cm = mag[r*CELL:(r+1)*CELL, c*CELL:(c+1)*CELL]
            ca = ang[r*CELL:(r+1)*CELL, c*CELL:(c+1)*CELL] % 180
            h, _ = np.histogram(ca, bins=BINS, range=(0, 180), weights=cm)
            norm = h / (h.sum() + 1e-6)
            feats.extend(norm.tolist())   # 64 cells × 9 = 576

    # 2. LBP: local binary pattern histogram → 256
    img8 = img
    h_lbp, w_lbp = img8.shape
    lbp = np.zeros_like(img8)
    neighbors = [(-1,-1),(-1,0),(-1,1),(0,1),(1,1),(1,0),(1,-1),(0,-1)]
    for bit, (dy, dx) in enumerate(neighbors):
        shifted = np.roll(np.roll(img8, dy, axis=0), dx, axis=1)
        lbp = lbp | ((shifted >= img8).astype(np.uint8) << bit)
    hist_lbp, _ = np.histogram(lbp.ravel(), bins=256, range=(0, 256))
    hist_lbp = hist_lbp / (hist_lbp.sum() + 1e-6)
    feats.extend(hist_lbp.tolist())       # 256

    # 3. Pixel stats per 4×4 grid of zones → 4×4×3 = 48
    ZONES = 4
    ZS = IMG_SIZE[0] // ZONES
    for r in range(ZONES):
        for c in range(ZONES):
            zone = gray[r*ZS:(r+1)*ZS, c*ZS:(c+1)*ZS]
            feats.append(float(zone.mean()))
            feats.append(float(zone.std()))
            feats.append(float(np.percentile(zone, 75) - np.percentile(zone, 25)))

    return np.array(feats, dtype=np.float32)   # 576+256+48 = 880


# ── Main ──────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  Smart Attendance — Improved Dataset Generation")
    print("=" * 60)

    all_X, all_y, all_names = [], [], []

    for idx, (sid, name) in enumerate(STUDENTS.items()):
        p = student_params(idx)
        for s in range(SAMPLES_PER_STUDENT):
            seed = idx * 10000 + s
            face = make_face(p, seed)
            feat = extract_features(face)
            all_X.append(feat)
            all_y.append(sid)
            all_names.append(name)
            if s < 2:
                cv2.imwrite(f"dataset/raw/{sid}_s{s}.png", face)

        print(f"  [{idx+1:02d}/10]  {sid} | {name:<20} | "
              f"feat_mean={np.mean([extract_features(make_face(p, idx*10000+s)) for s in range(5)], axis=0).mean():.4f}")

    X = np.vstack(all_X)
    y = np.array(all_y)
    print(f"\n[INFO] Dataset shape  : {X.shape}")
    print(f"[INFO] Feature range  : [{X.min():.3f}, {X.max():.3f}]")
    print(f"[INFO] Classes        : {len(np.unique(y))}")

    with open("dataset/processed/dataset.pkl", "wb") as f:
        pickle.dump({"X": X, "y": y, "names": all_names, "students": STUDENTS}, f)

    print("[SUCCESS] Saved → dataset/processed/dataset.pkl\n")


if __name__ == "__main__":
    main()
