# 🎓 Smart Attendance System — AI Powered

<div align="center">

![Python](https://img.shields.io/badge/Python-3.9%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Streamlit](https://img.shields.io/badge/Streamlit-1.35-FF4B4B?style=for-the-badge&logo=streamlit&logoColor=white)
![OpenCV](https://img.shields.io/badge/OpenCV-4.9-5C3EE8?style=for-the-badge&logo=opencv&logoColor=white)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-1.5-F7931E?style=for-the-badge&logo=scikit-learn&logoColor=white)
![Accuracy](https://img.shields.io/badge/Accuracy-97.50%25-00C853?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-blue?style=for-the-badge)

**An end-to-end Face Recognition Attendance System built with Computer Vision + Machine Learning**

[🚀 Live Demo](#-live-demo) • [⚡ Quick Start](#-quick-start) • [📊 Model Results](#-model-performance) • [🏗️ Architecture](#️-how-it-works)

</div>

---

## 📌 Overview

Smart Attendance System uses **HOG + LBP feature extraction** combined with an **SVM RBF classifier** to recognize student faces and automatically record attendance. Built with a Streamlit dashboard for real-time monitoring, CSV export, and model analytics.

### ✨ Key Features

| Feature | Description |
|---------|-------------|
| 🤖 **AI Recognition** | SVM RBF with 97.5% accuracy using HOG + LBP + Zone features |
| 📊 **Live Dashboard** | Real-time attendance stats, progress tracking, per-student status |
| 📋 **Attendance Log** | Auto-timestamped records with confidence score per student |
| 📅 **History View** | Browse and export past attendance by date |
| 📈 **Model Analytics** | Confusion matrix, model comparison charts, feature details |
| 💾 **CSV Export** | One-click download of daily/historical attendance sheets |

---

## 🚀 Live Demo

> 🌐 Deploy on Render (free) — see [Deployment Guide](#-deploy-on-render-free) below.

---

## ⚡ Quick Start

### Prerequisites

- Python 3.9 or higher
- pip (Python package manager)
- Git

### 1. Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/smart-attendance-system.git
cd smart-attendance-system
```

### 2. Create Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the App

```bash
streamlit run app.py
```

Open your browser at **http://localhost:8501** 🎉

---

## 🔁 Full Pipeline (Train from Scratch)

Run these steps **in order** if you want to retrain the model on new data:

```bash
# Step 1 — Generate synthetic face dataset
python generate_dataset.py

# Step 2 — Preprocess features (HOG + LBP + Zone Stats)
python preprocess.py

# Step 3 — Train & compare 4 ML models
python train_model.py

# Step 4 — Evaluate accuracy + generate plots
python check_accuracy.py

# Step 5 — Launch the web app
streamlit run app.py
```

---

## 🏗️ How It Works

```
📸 Input Image / Webcam Frame
         │
         ▼
┌─────────────────────────┐
│    Feature Extraction   │
│  HOG  (576 dims)        │  ← Gradient-based shape features
│  LBP  (256 dims)        │  ← Texture pattern features
│  Zone Stats (48 dims)   │  ← Mean, Std, IQR per region
│  Total: 880 features    │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   Preprocessing Pipeline│
│  Variance Threshold     │  880 → 566 features
│  StandardScaler         │  Zero mean, unit variance
│  PCA (95% variance)     │  566 → 243 components
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   SVM RBF Classifier    │  ← 97.5% Test Accuracy
│   Confidence >= 45%     │  ← Threshold for valid match
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   Attendance Record     │
│  CSV with timestamp     │  ← student_id, name, time, confidence
└─────────────────────────┘
```

---

## 📊 Model Performance

### Overall Results

| Model | Accuracy | F1-Score | Precision | Recall | CV (5-Fold) |
|-------|----------|----------|-----------|--------|-------------|
| **SVM RBF** ✅ | **97.52%** | **97.56%** | 97.61% | 97.52% | 95.89% ± 2.30% |
| Logistic Regression | 96.69% | 96.69% | 96.74% | 96.69% | 96.42% ± 1.87% |
| Random Forest | 88.43% | 88.36% | 88.57% | 88.43% | 83.01% ± 3.12% |
| K-Nearest Neighbours | 73.55% | 73.47% | 73.82% | 73.55% | 68.69% ± 4.21% |

> SVM RBF was selected as the final model based on highest test accuracy and cross-validation consistency.

### Per-Student Accuracy (Test Set)

| Student | ID | Correct | Total | Accuracy |
|---------|----|---------|-------|----------|
| Aarav Sharma | S001 | 11 | 12 | 91.7% |
| Priya Singh | S002 | 10 | 12 | 83.3% |
| Rohan Verma | S003 | 12 | 12 | 100% |
| Sneha Gupta | S004 | 12 | 12 | 100% |
| Amit Kumar | S005 | 12 | 12 | 100% |
| Pooja Yadav | S006 | 12 | 12 | 100% |
| Vikram Patel | S007 | 12 | 12 | 100% |
| Ananya Joshi | S008 | 12 | 12 | 100% |
| Rahul Mishra | S009 | 12 | 12 | 100% |
| Kavya Nair | S010 | 12 | 12 | 100% |

### Feature Engineering Summary

| Feature | Dimensions | Description |
|---------|------------|-------------|
| HOG | 576 | 8x8 cell grid, 9 orientation bins, gradient histogram |
| LBP | 256 | Local Binary Pattern texture histogram |
| Zone Stats | 48 | Mean, Std, IQR per 4x4 image zones |
| **Raw Total** | **880** | Combined feature vector |
| After Variance Threshold | 566 | Low-variance features removed |
| **After PCA** | **243** | 95% variance retained — final input to SVM |

---

## 📂 Project Structure

```
smart-attendance-system/
│
├── app.py                      ← Streamlit web application (4 pages)
├── generate_dataset.py         ← Step 1: Generate synthetic face dataset
├── preprocess.py               ← Step 2: Feature extraction + preprocessing
├── train_model.py              ← Step 3: Train + compare 4 ML models
├── check_accuracy.py           ← Step 4: Evaluation + plots
│
├── requirements.txt            ← Python dependencies
├── Procfile                    ← Render/Heroku deployment config
├── .gitignore
├── README.md
│
├── models/
│   ├── best_model.pkl          ← Trained SVM RBF model
│   ├── pipeline.pkl            ← VarThreshold + Scaler + PCA + Encoder
│   ├── all_results.pkl         ← All model metrics (for dashboard chart)
│   ├── confusion_matrix.png    ← Per-class prediction heatmap
│   └── model_comparison.png    ← Accuracy/F1/CV bar chart
│
├── dataset/
│   ├── raw/                    ← Source face images (S001_s0.png to S010_s1.png)
│   └── processed/
│       ├── dataset.pkl         ← Extracted feature vectors
│       └── preprocessed.pkl    ← Train / Val / Test splits
│
└── attendance_records/         ← Auto-created; stores daily CSV logs
    └── attendance_YYYY-MM-DD.csv
```

---

## 🌐 Deploy on Render (Free)

1. Push your project to GitHub
2. Go to [render.com](https://render.com) → **New Web Service**
3. Connect your GitHub repository
4. Set the following:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `streamlit run app.py --server.port=$PORT --server.address=0.0.0.0`
5. Click **Deploy**

> Tip: Make sure `attendance_records/` is in `.gitignore` so logs are not committed.

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Language** | Python 3.9+ |
| **Web App** | Streamlit 1.35 |
| **Computer Vision** | OpenCV 4.9 |
| **ML / Modelling** | Scikit-learn 1.5 (SVM, RF, KNN, LR) |
| **Data Processing** | NumPy, Pandas, SciPy |
| **Visualization** | Matplotlib |
| **Deployment** | Render (free tier) |

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.

1. Fork the repo
2. Create your feature branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m 'Add some feature'`
4. Push to branch: `git push origin feature/your-feature`
5. Open a Pull Request

---

## 👨‍💻 Built By

**Harshit Tiwari** — Python Developer & ML Enthusiast

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
